FiZk Seed Generator 
================== 
 
This tool helps you generate custom seeds for your FiZk account. 
 
Quick Start: 
1. Run FiZk-Seed-Generator.exe 
2. Enter your words or generate random ones 
3. Click 'Generate Seed' 
4. Copy the resulting seed to use during login 
 
For advanced users: 
- seedgen.py provides command-line functionality 
- seedgen.txt contains detailed documentation 
